import React from 'react';
import {
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Animatable from 'react-native-animatable';

const categories = [
  { name: 'Clothes', icon: require('../../assets/images/fashion.jpg') },
  { name: 'Electronics', icon: require('../../assets/images/favicon.png') },
  { name: 'Furniture', icon: require('../../assets/images/icon.png') },
  { name: 'Shoes', icon: require('../../assets/images/fasion2.jpg') },
  { name: 'Jewellery', icon: require('../../assets/images/jwellery.jpg') },
];

const products = [
  {
    title: 'Modern Minimalist Workstation Setup',
    price: '$49',
    rating: 4.7,
    image: require('../../assets/images/ecommerce-splash.png'),
  },
  {
    title: 'Modern Ergonomic Office Chair',
    price: '$71',
    rating: 4.3,
    image: require('../../assets/images/fashion3.jpg'),
  },
  {
    title: 'Modern Mahendi outfit',
    price: '$71',
    rating: 4.3,
    image: require('../../assets/images/fashion4.jpg'),
  },
  {
    title: 'shoes',
    price: '$71',
    rating: 4.3,
    image: require('../../assets/images/fasion6.webp'),
  },
  {
    title: 'shoes',
    price: '$71',
    rating: 4.3,
    image: require('../../assets/images/fashion8.jpg'),
  },
  {
    title: 'shoes',
    price: '$71',
    rating: 4.3,
    image: require('../../assets/images/fashion9.jpg'),
  },
];

const extraImages = [
  {
    title: 'New Arrival 1',
    price: '$59',
    rating: 4.5,
    image: { uri: '../../assets/images/fashion10.jpg' },
  },
  {
    title: 'New Arrival 2',
    price: '$39',
    rating: 4.2,
    image: { uri: '../../assets/images/fashion12.jpg' },
  },
  {
    title: 'New Arrival 3',
    price: '$89',
    rating: 4.6,
    image: { uri: '../../assets/images/fashion13.jpg' },
  },
  {
    title: 'Hot Deal 1',
    price: '$99',
    rating: 4.8,
    image: { uri: '../../assets/images/fashion14.jpg' },
  },
  {
    title: 'Hot Deal 2',
    price: '$65',
    rating: 4.4,
    image: { uri: '../../assets/images/fashion15.jpg' },
  },
  {
    title: 'Hot Deal 3',
    price: '$75',
    rating: 4.1,
    image: { uri: '../../assets/images/car.jpg' },
  },
];

const HomeScreen = () => {
  return (
    <ScrollView style={styles.container}>
      {/* Search Input */}
      <View style={styles.header}>
        <TextInput
          style={styles.search}
          placeholder="Search..."
          placeholderTextColor="#999"
        />
      </View>

      {/* Category Scroll */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
        {categories.map((item, index) => (
          <Animatable.View
            animation="fadeInRight"
            delay={index * 100}
            key={index}
            style={styles.categoryItem}
          >
            <Image source={item.icon} style={styles.categoryIcon} />
            <Text style={styles.categoryText}>{item.name}</Text>
          </Animatable.View>
        ))}
      </ScrollView>

      {/* Flash Sale Timer */}
      <View style={styles.flashSale}>
        <Text style={styles.flashText}>Flash Sale</Text>
        <View style={styles.timer}>
          <Text style={styles.timerText}>02:09:17:16</Text>
        </View>
      </View>

      {/* Main Product List - before banner */}
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={products.slice(0, 3)}
        keyExtractor={(item, index) => 'main-' + index.toString()}
        renderItem={({ item, index }) => (
          <Animatable.View animation="fadeInUp" delay={index * 150} style={styles.card}>
            <Image source={item.image} style={styles.productImage} />
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.price}>{item.price}</Text>
            <Text style={styles.rating}>⭐ {item.rating}</Text>
          </Animatable.View>
        )}
        style={styles.productList}
      />

      {/* Sale Banner */}
      <View style={styles.bannerContainer}>
        <Animatable.View animation="fadeInUp" delay={150}>
          <Image
            source={require('../../assets/images/sale2.jpg')}
            style={styles.banner}
          />
        </Animatable.View>
      </View>

      {/* Combined Extra 6 Cards Below Banner */}
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={extraImages}
        keyExtractor={(item, index) => 'extra-' + index.toString()}
        renderItem={({ item, index }) => (
          <Animatable.View animation="fadeInLeft" delay={index * 100} style={styles.card}>
            <Image source={item.image} style={styles.productImage} />
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.price}>{item.price}</Text>
            <Text style={styles.rating}>⭐ {item.rating}</Text>
          </Animatable.View>
        )}
        style={styles.productList}
      />

      {/* Remaining Main Product List - after extra images */}
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={products.slice(3)}
        keyExtractor={(item, index) => 'main2-' + index.toString()}
        renderItem={({ item, index }) => (
          <Animatable.View animation="fadeInUp" delay={index * 150} style={styles.card}>
            <Image source={item.image} style={styles.productImage} />
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.price}>{item.price}</Text>
            <Text style={styles.rating}>⭐ {item.rating}</Text>
          </Animatable.View>
        )}
        style={styles.productList}
      />

      <Text style={{alignItems:'center' , color:'blue' , alignSelf:'center' , border:4}}> click to see more </Text>
    </ScrollView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 40,
  },
  header: {
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  search: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 40,
  },
  categories: {
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  categoryItem: {
    alignItems: 'center',
    marginRight: 15,
  },
  categoryIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  categoryText: {
    fontSize: 12,
    marginTop: 5,
  },
  flashSale: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  flashText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  timer: {
    backgroundColor: '#FFD700',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 5,
  },
  timerText: {
    fontWeight: 'bold',
    color: '#000',
  },
  productList: {
    paddingLeft: 10,
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#f8f8f8',
    borderRadius: 12,
    marginRight: 15,
    padding: 10,
    width: 200,
  },
  productImage: {
    width: '100%',
    height: 120,
    borderRadius: 10,
    marginBottom: 8,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 14,
    marginBottom: 4,
  },
  price: {
    color: '#007bff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  rating: {
    marginTop: 4,
    color: '#666',
  },
  bannerContainer: {
    paddingHorizontal: 10,
    marginBottom: 25,
  },
  banner: {
    width: '95%',
    height: 350,
    borderRadius: 12,
    alignSelf: 'center',
    resizeMode: 'cover',
  },
});
