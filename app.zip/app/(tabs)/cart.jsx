import React, { useState } from 'react';
import {
  Animated,
  FlatList,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from 'react-native';

const initialCartItems = [
  {
    id: '1',
    name: 'Bluetooth Headphones',
    price: 59.99,
    quantity: 1,
    image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQA4AMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwEEBQYIAwL/xABEEAABAwMBBAcECAIHCQAAAAABAAIDBAURBhIhMVEHE0FhcYGRFCJCoRUyUnKCscHRYpIWIyRD4fDxCBcmNlOissLi/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFhEBAQEAAAAAAAAAAAAAAAAAAAER/9oADAMBAAIRAxEAPwCcUREBERAREQEREBERAVM78LyqqqKlhfNUPDI2je4rS7rqeesc+OkBig4Z+JyDcaivpaXPtFRFH95yxVdq60UUe2+faHNqibVeq6SyuNPTMbVXF/w5yGd5P6LVKe33TUD2z3iokZTvO033cNzyH+Sgmn/evpRr9iSsc09uy3bx6ZWQt/SHpS4yCOmvVMJDuDJHbBJ81zzU2CCnlLetyCTskuyFZ1Vq6tm4EjuQdcRyskaHRua9p4Oacgr7XK+nNVag0tO19vqXupsjap5SXMcOWOzyU+aE11btX0h6n+orogOupnHeO8cwg2xERAREQEREBERAREQEREBERAREQEREBeVRKyCJ0srwyNgJc49gXoVonSNfDH1drgdxHWT4PZ8Lf19EGI1Df33WsJBIpmHEbM/M9612+Xz6Jt3tDd8rzsQsO/aPM9wwqUsb6idrcYzxd2DnlW2lrT/TrXD5JWE2i3AZHNuTss8XHJPcD3K4Mj0adHP0oRfdRNLopXbccTuMvee5TKaGkfStpnU0Jp2jDYiwbIHcF7RsaxgY1oa1owGgbgOS+1BpV76OLTcS51M51M4/CPeatdqOixtHSyze3ySBjc7EbezzUr4VCAeKDmy729tASY5jNFne12O1a719XY7xBcbVM6GeJwdG8H1B5g9qlHpC0pNbqqSppmk0cxJbjgw/ZP6KO42NnDqeYbMjDgd6DofQ2qqfVthhuEIDJh7lRDnfHIOI8DxHctiXN/RtfHaV1lC2V+zQ3AinqATgAk+4/wAju8HFdH5QVREQEREBERAREQEREBERAREQEREHxM9kUbpJDhjAXE8gFBF2uTq+51FXKd80hcO4Z3DyAAUr9INf9H6UrXgkOlb1TcfxcfllQHLXlrsEeCsStiu1T7HpurqdoM2miJrvHj8vzUmdFOnxYdH0rZI9irrP7TUZ4hzgMNPgMBRU2I3qs0/ZpMhlVMJntDc7TQd4PkCPNdBxtDG7LRgDcEqx9oiKAiIgtq6jhrqWWmqWB8cjcOBUAawsDqC4TtjcBJE4jGcEjsPouiFFPS1TMp7tSVmxnr4ix3u53t/1QRHVvdPHgsxMBv8ADmukdBXg33SVtr3HMj4g2Q83N3E+fHzUNOq6OOlYZIRlkgyQ0cHZYfk7Pkt06A6p/wDR6st8rsmlnBAzzG/8kEpIiICIiAiIgIiICIiAiIgIiICoTjihWl9JWrxpe3tZC7+1VG5uOLR3d5QeHSNc6H+qoq0PfEw9Y5jN+XdgK0632G2aiLn0dGYWN4ySPH5cVqxvdVcA90NKJJ5QcyTOLg08+8/JX9pmuFK89ezLXDDnQ+67CsG26NZQwa6ndVmKnittC2CkMhxt5cdt3jwUnU9yoagkQVkEmPsyArnK8wT0NwZUVMz56eXJZJnG0O0HHarf2pkk4hppniSQ7MZc76juwE8icb+zKUdQNORkEEcwqrm7THSjdbDUiOr256cHEsEh3jnjPA9y6Fs9ypbxbKe4UEgkp6hgexw71BeIiICjXptGzbLZL2iocM/hUlKL+naTZs9sj+J1USP5SgjAP66me37QW99BR6u8Xun+y1px+LC0Ozs66tp4vtStb6kBSB0LR/8AE2opW/VzsD+crQmBERZBERAREQEREBERAREQEREFCud+leWa89IpoWkmKmaAByHb89r1XRB4KBLtTB+v7/VycGTdU31J/UJB826ijgja0Nws5SwNOMDKxsTveAWYojkhbRjtTWv2i0ytYN4G23ucO3z4KJZJix7XcjghT++LroXxkZDxhQTqGkNLdqymIw0PLm+BWaPLUzdutjrI+FVGJXbse/8AVcfMtz5qVf8AZ4v8rnV+n5nZY1vtUAJ3t3gPHhkg+ZUT3B/XUFBjiwPaf+3/ABW2dC1QaPX9BtO2WTxTRuJ4Y2C7/wBVFdMjgqrVrtri0W8lkbzVSj4YeHr+ywMvSZIH4jtg2eTpMn5IJHUOdONT1t0tVE3hEx8r+4ncP1W32jpDtdY9sNwa6hkccB0hBYT49nmo81R1l/1DX17cdSHdVET2hvL5+qsGL0hT5vMEz/qQB9Q/wY0n9lu/QPA51sulwk4z1AAPqT8ytOqHfROlLnVfVmrMUMH4t7yPAAeqlroztf0To23xObsvlb1zh97h8sJRtaIigIiICIiAiIgIiICIiAiIgoVDerYG0uo7mA3DpKgyHvy0KZVEOv8A/mis/B/4NVgwEb/fWYopN4WDjOCslTSYIwtI2mmk90HPBQvqcirnhrGfGZI3Y5seR+WFKgqxFTSPJ3NaT6BRI14MMkUx3Cd00bjv3O4j1AKlGIcdrZi7GOdjzwsjZnikr6ac7th2Se7BCt3RZqHEtx+2Ny+64GK3SOG4kYHqsqv6vVbutcyIsa0biS3JPljCzViuJuMbtt8b9niWHgo13k8yVvmiKCSnojPLGQ6od7ufsj90GZukDH0UwdnY6slxceK+dD1f0hbJIJal7KqJvVQgP3kHhuOR8lXWNSKK3MoWgGeobk9zefdw/NYHT0U1I+OpjY49VURnxGd/yVGzy0EuoNb2rS8c/XUlHl0z2tDcE+9K444nGGg7hvG5dAsY2NjWRtDWtGGgcAAo26JLPAKy937YPWVE/Uwl3EMADnY8SQPwhSYpQREQEREBERAREQEREBERAREQUPBRb0mU5ivzJsYbNADnmQSD+ilM8Fq3SBZX3S0CWnaXVFKS9oHFzfiH6+SQRIDgq6jl2cb1aO93jzXwZMbsraLy61vV22YB2942QtHbAZJgMdo3LO3CUyAMJOBvwrakgDTtHszjxQWj6YOncQN2cBYzUuIqSOIcXOzjuC2FgDc8MBYS5Uoq60SVb9mnjGAxp95/7LCrHTtpNdMZp24pmO97+M/ZH6qSaZ0Nspfb5w3Z+qyA/F4LXrXs9W2eVoipY90cQ3Z8P3Xjcqua51IafcgxgAbt3JBbPMl2rnTOJIyQza7B+y89Q1ppmMpYf7rDnjm/sCvnyRWuk615w852M8AO0/55hYO30kt3rH1LtoUzHZBPxHmgnrobuHX2yupD/czNe3f2OaAcfiafVSKo96IrLLQ22puM7SwVZa2Fp/6bfi8yT5AKQkBERAREQEREBERAREQEREBERAVCMqqINO1LoaluT31VCW09Ud7m8GSHw7Co4vFjr7U50dVSyR79zuLT4FTuRleVTTQ1ULoqiJksbuLXjIKujnF1O8OzLho715TP2WkMBA71Px0nYM5+iqbP3VFevdN/RNa47BdRynMWOGO0eIUEc3G57LDT0LTLM7iW7w1elptcoaKmvO07i2Ln94/osjGKaI5jiYCvV1QXjGdyDznJld7+8dgA4dw5Be1NGMF0uAwceat9rGcbyqbZcPf3nkqLa5wsrbhA+UF1KJAZGjP1eweH+PlJuidFi6OjqqqHqbUw5ZGBjrv/AJ/NYzo/0ZLf5mV9awx2qM7idxnI7B3cyptjibFG2ONoYxo2WtAwAOSCscbY42sY0Na0YaBwAX2iKAiIgIiICIiAiIgIiICIiAiIgIiICIiArO5WyjulK6mr4GTQu+E9h5g9hV4iCH9TdFdXTl8+npvaoxv9mmcGyDua7gfPHiVHdXS3WglMNZbKyne3i2SI/nwXULyBvdleTquBn1nH+UoOarbZL9dpGNt9prJNo73mMsYPFx3KSdJ9FfVPZVanlZM4YIooTlgP8bvi8Bu55Ckj2+mPxHH3SvttbAfquPog9I4WRRtjja1kbRgNaMADsAHYvVeIqI8dvovoStKD0RfO2FXaCCqKmUQVRURBVFRVQEREBERAREQEREBERAREQEREBUwOSIgpsjkPRNhv2R6IiCuyOQTZbyCIgYHJMBEQMKqIgIiICIiAiIg//9k=', // Updated for preview
  },
  {
    id: '2',
    name: 'Smart Watch',
    price: 99.99,
    quantity: 2,
    image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQMEBQYHAgj/xABLEAABAwIDAggJCQQIBwAAAAABAAIDBBEFEiEGMQcTIkFRYXGRFDI1UnSBkqGyFRYjQlNUlNHSF3KxwSQzc4KTs/DxNkNVVmJjhP/EABgBAQEBAQEAAAAAAAAAAAAAAAADAQQC/8QAJREBAAIBAwIGAwAAAAAAAAAAAAECAwQRMRITIUFxgcHRBSJR/9oADAMBAAIRAxEAPwDreVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVGVPZUZUDOVKncqEDuVGVOWRZA3lTU00MABmkay+6539ik2VLVRmasledbHKOwIJRxKlG5zz2Ru/JIMTpPOeO2MqKKcdCDTjoQWENXTTuDY5Wl53NOh7in8qo5KY2u3Rw1BHMVewnPEx/nNBQJlRlTlkWQN5V5keyJhfK9rGDe5xsE9ZU+NMM08Uf1WNzW6z/t70D7sUom/80u/dY4/yXn5Wo/Ok/w3fkq9tL1Be/BupBYx4jRyEATtaTuzgt/ipeVUD6UEWICuMKv4E1rjcsJb6gdPcgfyoypyyLIG8qE5ZCByyLL1ZG7egbe5rGl7tAFXMhcbuLTdzi46dJuuHcI+3+JR43FHEGOhAEuSQZmhp1DQ06Xy2u4gm5NrDRR4eFqBkbWvwKnLgNSI2fkg77xR809yOKPmlcG/a5S/9Ag9hn5JP2uUv/b0Hcz8kHeDCT9U9yk0ZAgbGbh7BYghfPr+FukI5OzkBPWW/kqij4RMSkx+GaCGKmge8N4uABjmi+8OAHcbjpCD6hsiyrtnK+TEcKjnntxwLo5C0WDnNJFx0X325rqzsg8Gw3qsmbx9S6RoOWwA6x0rmfDHtlXYa91JRkBgeYg118pIaC5zh9bxgA06aEm+lsZh3Co2npWRVODU0sgGrxGzX3IPoAQHzT3L1xP/AInuXCDwtU437PwewwfyR+1ul59noO5n5IO7GAkaNPcnaH6IvieCC52ZvcNPcuBu4W6Qj/h2C/8Ad/JUeL8JNZVVMcuH0FJRsYbluQEu9YAI7QQg+pbIsspweY7NjOEA1JLpGxska5xucrrixPOQWuF+cWvrda2yDzZC9WQgVI/xHdiVI/xHdiD5J4RvLcfo0PwBZRavhF8tx+jQ/AFBbsxWN2Xl2gnMcVM17GxxuP0kocSM4HM27Trz2NtyCiQrqg2dq63Z7EscaWx0lCWtJdvkc5wGVvZmBJ6x0p7ZvZuPGqWuq6nFabDaajMTXyVDXEEvzW8UHzSgz6lYZ5Qp/wB8K/wfZBuJMzvxejpGT1TqTD3TB/8ATJRbxbDkt1byjzuAVJSwSU2Mx087CyWKbI9h3tcDYjvQfVewtdTOpJKASHwmOWR7mFpHJLt4NrHeNy1Kxux74HVlOyMtMrYJ84HN9Iyy2SD514dPKJ9Kk+GNc5wXBMQxuqNPhtO6aQDM625o6SujcOflI+lSfDGslsRjVRs/LUVRoJ56SZga97Gnk2vrfdzrxkm0Vma8qYorN4i8+CbT4TXY1trR4VtFCKZwZymNGXO0AkWPX/BbjbLYTAYtnqqejijp56ZhcxzGFp0BOupvutqub47tJWY1tDT1+GRSQTRANp2x8p9xp/oK02oxvbKpwnicVgMNG+3Guib4372psO5cOamoy5KX6tv74/HmtW+mwxOOPZVxYHjOPYNTz0WGRCGkjdy2WDpRfUm+9ZlzSxxDhYtNiCui7LcIUmHbPDB2YfLNO0WjdCLl461kK00ngdQaynqYsYkqTJym5WBh1Oh67rvjq5mEsvarWvTO8u+cE1dT0tJBBO8tkqKWNsXJNnEPk0vawOo3rpy5TwePgGDYZG4t450kGQc9s7rrqy9JBCEIBI/xHdiVI/xHdiD5J4RfLcfosPwBTtn8BxWq4PMdqIKR8kM8lO+F2durYjLnO/muoPCN5bj9Gh+ALKIOo0mM7N1+xuJ0ccGLQ09Fh8UbohJEA5xmYXPGnjOfYm/MLDcFA2NwraTDcUqsMODUdVQvmpxibKtjJIo22zAkk8mzXk3G5Y44NXig8N8HcacgEuBBIudLjr5klHhuI1kjoKaGV0jixjoycpOY2bod4v3IOgU2GsxqnwWPZ17JKPB8bqTM4yAGGB8jHMldc+LlY7XqWLxOrhr9tKusprcTPXySR252l5IKpnZ4y5pu1wu1wB9xT+Ga4jT3+0CD6z2GZD8lyyMYzjvCHh7g0ZjrpcrSrL7AeTqv0p61CD524cbfKfKvl8Lkvbf4sa1GHOwmTAYW0xomRiC7HEOBtl01Gm9Zbh08on0qT4Y1k9htn37RyVNM+ulggia36FjyONc42tuIG47wsmdo3l7x0te0VrysdhH4W3bqoymMREuFMXC7d+tvVf1LrW1BghwSbw6pg+T2QkRw8lznC2pJ9Zv3LiG02zU2C4/BRYdJLKZgHwOOj77jqOsHVOY9hW0sWHtlxKrfUUwFy0TOcLXtcggX1G/VStp7Zv3rw4dXirTN0XttMrjgndSh9eLxCuygxZyAS24va/r9yf4WXUppKK5iNdxrjybZuL13267f6uvOy3B9FiWCQYk/EJ4amZpfFxLgAwc19Ln1ELn+IiaOtqIqiV0skcjmOe5172Nt5XfGqjs9rZTJ+PvTNGe08vo/ghjhdRROexhlFHGY3FouBnkvY+sd66UuZcEf9XSegH/MC6auZcIQhAJH+I7sSpCLiyD5I4RvLcfo0PwBZVdP4UNjMTjxlj4mxuaGCNueRsecN0a5pcQDpa4vcG/NYrGfNPGfu0P4uH9SCuGJVjYRA2rqRCBbixM7Lvvu7dUgxGsD3PbV1Ic62YiV1zY3F9eYqy+aeM/dofxcP6kfNPGfu0P4uH9SCkc4uJLiSSbknnUnDPKNN/aBWXzTxn7tD+Mh/UrDAtjcWmxamY+GNgzgnJOyRxF/qtaSSfVbpIQfR+wTHNwypcQQHVT7HpWnVVszQS4dhMUNQA2ZxdI9oN8hcSct+ewsL9StUHzrw6eUT6VJ8Ma5xguKV+GVYdhkr2yy2ZlAuH66Ajn1XZ+GrZSvrHmrpWtMZl4wOe7K3VrQWlx0Bu0EXsCDa9xryQbKYyHXFPCNdP6ZD+pZMbxs2tprO8SsKioxPA9rIaraNpMxZqGkEBhBHJtpp0dq2W23CBhWJ4IKWip6Vj8rmsbAOYgjXQWAvdYSswDaKum46tDZ5bAZ5K2Imw3fXTPzUxn7tD+Lh/UqYct6Y4rO0yhqNPTNl7kzP35phxTHtnMJpYIa6PweqjL4w2znRjqJ3b+ZZZzi5xLjck3JKvDspjJ308J/+yH9SWPZHGHSMaYKdoc4C7qyKwv2Ov3KcRMcurJkm/pDvHBE1xgp3gXaygs49F5NPhPcumLHcGuC1GE4O01bS17o2RsBBBLW3Oax1Fy42B1sB2LYrUwhCEAhJdF0EeuoqeupnU9VGJIncx5j0joKxJwyjjlkic0Ese5pNt9iQt9dc+x+Z1HjlVG7kgkSN6wefvugfbh1F5g7kHDaG39W3uVc3ERbeO9ejiItvHeglvw+itoxvctPs5hVLRUbJ4YwJpmhzn21tzDsWGkry45GXLnaNDd5J3BdMpWcTTQxG12MDdOoIHUJLougSRjZGFj2hzXCxaRcELH4hg9FS1z4mMAYQHNHQDfRbG4WV2ueaesp5rHLIwtv1g3/AIFBFbh1H5g7l6+TqPzB3KAyu03+9e/Duv3oJTsOox9Qdys9nsJoxI+rEbTIx+VhI8XQa9uqz767Tf71rdmmkYTE9wIMhL+0E6e6yC0AslSXCLoFQkuhAznRnUfOjOgclkmt9GGkqgxumdWgNq6WGVwHIJHKHYRqrvMoM3KmcUGOnwKbN9DTOA6pT/NNtwKq+tTuI/tFs7IyoKXB8NNJOyVlFE2ZviveS4g9VybLUQyVVhxgaOlQC3W/QrBr7tBQSA/TVLnUfOjOgckkkt9Hb1qqxQVM0Do54YZIiRyXi4urHOolYcz29QQZGowmcuPE0th1Sm3vTIwqu54Hf4i12VerIM/RYZkeHT0bHn/2vLh3XstXTyVRaM7WWtpZQiFMpnWiaOhBMa825Vr9SXOo+dGdBIzoUfOhBHzIzJjjOtHGIHXzMjF3va0c1yo/Hwk3MsftBV9RG6V5e83JPcE1xB60Ftx8H2sftBHHw/ax+0FU+DnoKPBz0FBameD7aMf3gnoqiJ/JZI0noDgqTwc9BStgIcDrvQX+ZJmUWCR3FNzm7ude+MQPmQNF3OAHSVHdUQudfjWe0FCrQ6WTU3aNwUXwc9aC24+D7WP2gjj4PtY/aCqfBz1o8G6igtePh+1j9oL3FVQjk8cy5OnKCp/Bj0FHg56EF/mRmUCkc5keRxuBuupHGIH8yVR+MQgj3S3Qha0iLpUIEui6VCBLoSoQIi6VCBEIQjAi6VCBLoSoRoGiS6VCMJdKhCNf/9k=', // Updated for preview
  },
  {
    id: '3',
    name: 'Wireless Charger',
    price: 10.99,
    quantity: 1,
    image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8QEBANEA8QDxAPDw8PDxAQEBAPDw8PFREXFhURFRUYHSggGB0lGxUVITEhJSkrLi4uFx8/ODMsOigtLisBCgoKDg0OGhAQGDMgHSUtLS0uKysvListLy0vNy0uKy0rLy0rLi83LS03Ly0rNy4vLS0tLS03NzEtNy0tKy0vLf/AABEIANsA5gMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIHBAUGAwj/xABIEAABAwIEAwQGBgYGCwEAAAABAAIDBBEFEiExBkFRBxMiYTJCcYGRsRRSYoKSoUNTcsHR8CMzY5Oy4RUkRHODhKKzwtLxFv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAwL/xAArEQEAAgECBAMIAwAAAAAAAAAAAQIRITEDEkFhUZGxEyJxgaHB4fAyUtH/2gAMAwEAAhEDEQA/ALxQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAQhCAWBjeMU9FC6pqZBHG3TmXOdyYxo1c49AtbxfxfS4ZGHTOzyvBMMDCO8ktz+y0c3HT2mwNCYpi2JY/WtijaZJDcRxsuIKaK+pBOw2zSHUm32WoM3jrtNqayQCJ8tLAxxyRRTOikJ5OlkYQS63qg5R52umrS4K4EosKj8YbU1UjQJpntBAG/dxtPotuPabC+wAEHeIQhAIQhAIQhAIQhAIQhAIQhAIQhAIQhAIQhAIQhAIQhAIXlU1DI2Okke1jGi7nOIa1o8yVWXF/HrpM0FMXRx6gv1ZLIPnG3y9I6Xy6gh3cvE1C2U07qmNsgOU3JDA76uf0b8rXuuL427V4KZj2UdpZb5RM/+oGmr2C95bHTk073POrMQxC2m5tYAbAdAOS5/EDFcGZpkfcEtY7K5rL6+LlpfdB0HD2AYhj9Q+TvHd3n/wBZrJruAO+XS2Z1to22AFvRFlevD+CUeFwfRqVlibGWV1jLM8D0nu+QGg5AL0w6SJlPDHTRtig7tpiYxuVoY4Zhp111PVe1LTGQ67IIhr5CShbyGENFgEIPVCEIBCEIBCEIBCTnAblazEcepoATJKxtt7uGiObWiu8toldV5inahTMuIg6U+QsPidD8Vy9f2mVb7iNjIx1Pi/L/ADRz7SZ2ifT1XUZB1UHVDBu4BfPlVxhXv3qCPJoFv+q610uM1Tt55fc4t+SYkzxPCPP8Po84jCN5GD7wSbiUB2lZ+Jq+ajiNR+vm/vZP4oGIz/r5v71/8VcHv9n04ydp2cD7FMOHVfMkeN1TdWzv99nfMLZ0nHOIRWtNmHR2b5AgfkmDN/B9EoVMYd2rztsJY8w5luV35eG3xK7HB+0ihms1zwxx5O8Jv7HWv7rqHtMfyjDtkLHpK6KUXje11twD4h7RuFkI7iYmMwEibanRNcZxnxPNQTsdPSSSYc6NmaphOYwzZjfvWbZQMpBJHlc2AK4rjzEMXdJLJNTkUbZpG0whdmLYmuLWzPANszgLi9iA7Tz4CqxC/hj8RPt09t9l9BUOJUlVCamGojkh9Z4Pok+q9p1a7UeEi+uyrHtG4WzNE1HR1DqiSZsQjpoXuysIuXzkC0RItZm4DrutewCsqqtyXDSHP9aQ+izyHmrB4C7NC/LWYg0hps9lK7R8nR0/QfY3PPoeg4E7N20IZU1bWyVQ8TGDxxUx5EH15PtbDl9Y90TyCAJtoPd0C2WEsdqTsvOioL+Jy2zWgCwQNCEIBCEIBCFj1lYyJpe9wAAuSUSZiIzL3c4Ddc3xDxjS0gOZ4LuTG6uJXC8X9ob3l0NKbN1Bl/8AXr/O6r2aVzyXOcXOO5JuSrEM82ttpDr8d7Q6ue7Yv6Fh6avsuRnnfIcz3OeeriT8Oi81EuVdxSINIuUSUkdGSkkSkSgZKiSkSkSgCUiUiUiUDJUSUXUUGywzHaqmIMMzgG7NJLmD2D1fu2Vj8N9rG0dW23LPfT8XL7w+8qmUSUw4nhxvGk9n1VhmKQ1Lc8Tw4WBI0zAHYkdPPYrLc0EEEXBFiDqCOi+XcC4gqaJ4fC8gA3yXOXzt9U/keYKu/grj6CuaI3kRzCwIOlzyv0v12PkdEx4JzTGlvMTcBUkVYzEKUPpXNzd5HTlrYZQWkWLCDk3v4ba676rpqWRjWhgaGAbNHxWavN1O0m9ly0Y88RcNAoUdBl1dus8CyaAAQhCAQhCAQheNXUNjaXONgATc9ESZxqx8VxKOnjdI9waGi5JsqQ4w4vlrXljSWQAmzRoX+Z8v58l68ecUuq5TEwkQsJG/puB39i5IlIjqyrHP707dI+5pEqJco3XTYyUkKJcgkSolyiSkSgd0iUiVElBIlRJSJSugZKV0rpEoGSokpEpIGSkldK6B3U6epfG4SMcWvbsR8vMeR3XkSokqkxle3Ztx82qaKaoIbMwAXJ3GwNzqW7DqCbG9wTY6+RqSrfFI2aN2V7Ddp+YI5gi4I5gr6G7OeLW11O0ONpGjKQTctcBqwnna4IPNpHMFcyyieScTtO3+OzQhCjUIQhAIQhAEqs+1PiQxs+ixus+T0iN2t/n5jorBxOpEUbnnYAk+5fOXEGJOqamWYm93EN/ZB/8Ap96Yyyv71or06sAuSukkSumppXUSUroGSokpEpXQMlIlK6iSgZKRKV0roGkSkSo3QSJUUrpEoHdIlIlRJQSJUSVEuSJQMlK6jdIlA7rf8E466jq2PzZY5C1kh5NN/BIfYTr9lzlzxKi7ojm9YtExL68w2rE0bZBpcajo4aEe4rKVe9kGNmopWtcbvDbOubnvIyGOJ8y3I77ysJcueFabV132n5BCEI0CEIQcZ2m4gYqSQA2JblHtcbD96ohWz2xT/wBEG/2rB8Bf/wAlUZK6jZlw9bWnukSo3SuldGp3SuokpEoGSldIpIGSvakqe7JIaMx0DiXjI0gh1spBB13BuNbb3GMSkSg2zooZW5g52fvAZZHNF2RCwL8jXai749Tc6OudCsSWhcC8NIPdkNe11o3NebjLqcpN2n0XG9tOdsRryCHAkEagg2IPkUOlcWhl/CCSBoNTuT1Og1PRArpErYuqInF1y4x38EPcgOZc+BjC134jcE+ZNx5VWFvY1z7+GNozOIID3FwFmaajxN1Nr62uEGCSokqdRA+M2e0t3tfYkbgHbTn0XiSgkXKJKV1G6CV1G6RKiSgldRJSJSugd0rpIQWd2IYgWTyQ8u8icP8AiNcx3+CNX2vmbstnLa11v1Qd7xNHb5lfTDToCpMMqaXt8vSDQhCjUIQhBU3awM0MjvqVLf8ACwKqSVcfHVOZY6+IaubkmA+7p+bVTN1aseHpa0d8/vkZKRKV0lWxkpXSJUSUEiVElK6V0DJSJUSVElBIlIlRJUSUDJXpBVOYSWkXNr3AO2rTrsQQCPMDovAlIlBsm1rXiz8rDeO7nMEgd4bSPIyG7zZhu4HY6i+rmo2uIy3zyatyjKw3AtZpFrbl2V/guRYhq1ZKBIQCASA64cAbAjz6oPaqp3R2vqHZgDZzblu4s4Ag6jcc1jkqU0xebncNY33NaGj5fEleSCRKV0kXTIEJEpXUDuldK6V0HZ9mUd555Pqxxs973Ej/ALa+lqc+Bv7I+S+fezqlyUzJD6VZWsYy2/dxa3PvjmH3gvoOEWa0eQSZ2ZcPW1p7+iaEIUahCEIOE4ltHiEYd6FXG6Ak7Z92H4jKPNypbHqA01TLARYNcS39gnT+HuV5dpuGulpTIwlskRD2PHpMcDcOHmCAfcq64qhGI0UWKxNAljBjqo26lkjdJGe4+IdWnzTaWF/cvF+m0/ZwJKRKiSlddNzJSukSokoGSkSolyiSgkSokqJKRKBkpEpEqJKCRKiSokoQMlK6SLpkCErpEqB3SJSuokoHdIlIlIlAyV6UlM+aRkEYu+V7WMHLMTa58huT0BXjddzwRQtpIJcaqGA5QY6ON36WRwIBHtsRf6rXnmFHHEvyxpv0+LtOHaVpxGmoY7mLDqdrD0M0ga438wxsZ9sjlcgVX9juFPyyVkpLpJnuke87ukeczj8SrQQ4dOSsVCEIR2EIQgx66nEsb4zs5pCottacHxCWOcH6DVuEdRzEL72jqQPLY+VtyAFfi4LtN4VFVCZWtu5oOYfWaiTETGJVXx1ww6jk72MZqaWzmubq1ubUWI9U8j7ul+UJXacJcSNgBwXFPFSOu2mqHi/0e+ndyf2f+H2ejr+MuEJaF5e0F9OdWvHiytO1zzHR3x87DKkzSeW3yn7OZLlElRJSJVbGSldIlRLkEiVElRJSQMlJCRKZDSuldJQO6V0rpEoGSkSokpXQSJSuo3SugldIlRJXU8H8Gy1p76X+hpWDO6RxyZ2A6kH1W/a9wudjm1orGZQ4L4XNdIZJfBSRXdNI4lrXBurm5uQHM8thqQuorZTiNXFTQtLaaAhkDLZdNLyOHImw05ANHI39sexJgYygpG5IG5QAG5TMQdHuHJoN8rOupub277s04U7hgqZW+N2ovuElxWszPNbfp2/LscBw5tNAyEDZov7VsUIUahCEIBCrjjftUho5Po9I2OplY4tme95bBGRcGMObfM8He2gtbfQCCx0nNBBB1B3TQgqTtK4DDs1RC24OrgNweoXH8L8US0jfoFUw1FJq1rD/AFkI6xE+r9g6dCOf0S9gcC0i4O4Vb8b9nrZc09OAHblo6+SJMRMYlwWN8GRTNNVhsjXtOpivYA75RfVh+yfyXC1UL4nmORjo3t3a4WI/y8118D56OQtdmicNCeRHRw2P87LdVFZBVMDKqFkgto4XBb5seNW/mrlni1NtY+qryUrrsq3ggPu+ina8fqpyGvHk2QeF3vA9q5fEcNqKc2nhkh83t8B9jx4T7imXVeJW2kTr4MVK6V0iUdmSldIlRugkSokpJXQO6V0iUiUDJSukSthheB1dVbuKeR7T69skX43Wb+aJMxEZlr7r2oqSWd4ihjdLIdmsFzbqeg8zouzg4HpqZomxOtjiG4iiJu7yBIzO9jW+9ZZ40gp2fR8KpWwt27+VgMjjawc2PW528Ty4+SmWftJt/CM9+j1wbgSnpGNq8Vkbc6x0zPGXkcg39J7TZg53WZjHEL57QxMEcYI7uBpJ15Pld67rfDkButNh1FWVspcTJLI8+KR5LnH3nYeXLyVucHcAx0wEswzyb2PIotaYnMzmf3ZqeAuBySKupFyfEAVaLGgAACwGgQ1oAsNAE0aBCF4VtZFBG+eaRsUUbS573kNa1o5klB7E21OgG6pbtN7T8wfRUMhbFq2WpYbPm6sid6rOr9zysNTqO0ntMfWZqSmzRUhuHA+GWqHWT6kZ+pufW3yjbdm/ZiSWYlijOj4KR4t5tfM07eUf4uiDScDdl02IxfS6uR9JTuaPozWsb3kg+uGuFmstsd3bjSxIrrqq0k6aAIQbtCEIBCEINFj/AAvTVjTnYA7k4DVVhjnAFXTEugJezU23/JXYkQg+aJpZ4XatfE8c23H5fu1WVS8cTReCaKOoZzBPdPI87Ag+9qvnE+HqWoBEkTSTztquJxnsqhfcxOt0a4XCObUrbeHA/wCkOGqu/fxSUDydXCJwaT1vASPxNUh2f4dUX+hYxA8nUMMsEjwP2SWOUsZ7KKlt8rCfNh/cbrka7garjv4T95hH5i/yUw49ljaZj975dLVdkWIt1jfFIOpEjdPuhy1k3Zpirf0UZ9jpB82BaOmwqugPgc+P/dSyR/Ky21JieKs/2uuH/NzEfDOqvLf+30I9nuKfqo/7z/JejeznETv3DfbJJp8GLYxY/XevVVZ9ssp/esj/AErK70n1D/a5zvm5Uxfxjy/LWt7OJm6zVkEfXKyR9vxZVL/8zhMOs1ZNORuI8jGnys0OcPisiRssnowyE/aFvldEfClbMdIXAHyPzUTktO9vRiHHsMpTelw5r3jaSbxkHqHPzEfALW13HGI1BLI3d0NssLSXAebjcj2iy7fDeyaoksZGgftG/wCQ0Xa4N2W00Vu8Oa3qgWCLHCrGuM/HVRWHcNVdVJmdnc5x1JJkkd7XH+JVpcJ9lbtHzeAaXG7j71a+HYLT04Ajja23OwutgjRrcIwSClaGxMAtztqtkhCAWDi+Kw0sZlmdlGzWjV8jrei1vM/LUmwBKwOJuJ4aJpBs+Ytu2IG1hyc8+q24PmbGwNjam+IOIJal5llfc2t0DW/Va31W+W55knVBYs3ahSNjkPcy940eCO7MsjibAZ7+G25Ntts2yp/jXjisxSdlO27gHNbFTQsdk706Zg3eR2tgTtyAub66qqy+4Bysb6TjsFm9n2Kubi1GYYg9pe+K5beTK9ha+QH1crbm/QHqgsrs57N46HLX14bLWaPjiJD2Up6k7Pk89hyv6R7ipqnPNgoSvLuazsMpm2zHUoI0lBpd3NC2qEAhCEAhCEAhCEAhCEAvKSmjd6TGn2gL1Qg18mC0zt4WH3BeLuG6M/oGfBbZCDTjhmi/UM+C9WYBSDaBnwWzQgxY8OhbtEwe4LIbG0bAD3KSEAhCEAhCEAtXxLPUMpZvomQ1TmFtOJCAzvDpmN+QFz7ltFXLOOu5ndS4rTSUMxe4RzHNLSysDtC14Gg22BA9Yg3QV5xBDiEDya2Jz7m5nju9sjvrG+5/cBoNly1VV57uLssTd3dfIL6NrHwPiaWlk4naTE1jmPZKwDV+b0QwXF3HQXG5IBqfiXs6qaqtijpKUxwSND5qt+VlLe97xsvmsBoAQHOJOzbWDgcPoajEJmUlPGXX1azZoYDrLI71Wi418wBckBXpwbwhT4bH4bSVD2gTVBFi7nkYPVYDy58/LP4d4Ygw2HuIW6usZZXW7yZ49Zx6dG7D4raMYXGwQIXcbBbrD4C1uvNKjow0XO6zEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAsXEcPgqYzDPFHNG7dkjQ9t+RsdiOqykIOMwPgunw+SZ0BmMMzo3Gme/PCxzL2cLjMfS9YnUDewt1EdQD7VlOC8BE3NeyDxqKYvC9aWlDB5rJQgEIQgEIQg/9k=', // Updated for preview
  },
];

const CartScreen = () => {
  const { width } = useWindowDimensions();
  const isSmallScreen = width < 360;

  const [cartItems, setCartItems] = useState(initialCartItems);
  const [fadeAnim] = useState(new Animated.Value(0));

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  const updateQuantity = (id, delta) => {
    const updatedItems = cartItems.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        return { ...item, quantity: newQty > 0 ? newQty : 1 };
      }
      return item;
    });
    setCartItems(updatedItems);
  };

  const total = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
        <Text style={[styles.heading, { fontSize: isSmallScreen ? 22 : 28 }]}>🛒 My Cart</Text>

        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          renderItem={({ item }) => (
            <Animated.View style={styles.card}>
              <Image source={{ uri: item.image }} style={styles.productImage} />
              <View style={styles.cardInfo}>
                <Text style={[styles.productName, { fontSize: isSmallScreen ? 14 : 16 }]}>
                  {item.name}
                </Text>
                <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>

                <View style={styles.quantityContainer}>
                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => updateQuantity(item.id, -1)}
                  >
                    <Text style={styles.quantityText}>-</Text>
                  </TouchableOpacity>
                  <Text style={styles.quantityNumber}>{item.quantity}</Text>
                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => updateQuantity(item.id, 1)}
                  >
                    <Text style={styles.quantityText}>+</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Animated.View>
          )}
        />

        <View style={styles.summary}>
          <View style={styles.summaryRow}>
            <Text style={styles.label}>Subtotal</Text>
            <Text style={styles.value}>${total.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.label}>Shipping</Text>
            <Text style={styles.value}>$5.00</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>${(total + 5).toFixed(2)}</Text>
          </View>

          <TouchableOpacity style={styles.checkoutButton}>
            <Text style={styles.checkoutText}>Proceed to Checkout</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
};

export default CartScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fefefe',
    paddingTop: 50,
    paddingHorizontal: 16,
  },
  heading: {
    fontWeight: '700',
    color: '#333',
    marginBottom: 20,
  },
  listContainer: {
    paddingBottom: 20,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 12,
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 6,
  },
  productImage: {
    width: 70,
    height: 70,
    borderRadius: 10,
    marginRight: 12,
  },
  cardInfo: {
    flex: 1,
    justifyContent: 'space-between',
  },
  productName: {
    fontWeight: '600',
    color: '#222',
  },
  productPrice: {
    fontSize: 14,
    color: '#666',
    marginVertical: 4,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  quantityButton: {
    backgroundColor: '#eee',
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginHorizontal: 6,
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '600',
  },
  quantityNumber: {
    fontSize: 16,
    fontWeight: '600',
  },
  summary: {
    borderTopWidth: 1,
    borderColor: '#ddd',
    paddingTop: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  label: {
    fontSize: 15,
    color: '#444',
  },
  value: {
    fontSize: 15,
    fontWeight: '500',
    color: '#444',
  },
  totalLabel: {
    fontSize: 17,
    fontWeight: '700',
  },
  totalValue: {
    fontSize: 17,
    fontWeight: '700',
    color: '#000',
  },
  checkoutButton: {
    backgroundColor: '#333',
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 20,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
});
