import React from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import Animated, {
  FadeInUp,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';

const screenWidth = Dimensions.get('window').width;

const categories = ['Clothing', 'Electronics', 'Shoes', 'Home', 'Beauty'];

const featuredProducts = [
  {
    id: '1',
    name: 'Lehenga',
    price: '$99.99',
    image: '../../../assets/images/sale5.webp',
  },
  {
    id: '2',
    name: 'Bridal Dress',
    price: '$59.99',
    image: '../../assets/images/section.jpg',
  },
  {
    id: '3',
    name: 'Makeup Kit',
    price: '$79.99',
    image: 'https://i.imgur.com/vuH8PSP.jpg',
  },
  {
    id: '4',
    name: 'Eyelashes',
    price: '$39.99',
    image: 'https://i.imgur.com/1N0WZ4H.jpg',
  },
];

const newArrivals = [
  {
    id: '5',
    name: 'Smart Watch',
    price: '$149.99',
    image: 'https://i.imgur.com/KZsmUi2l.jpg',
  },
  {
    id: '6',
    name: 'Sneakers',
    price: '$89.99',
    image: 'https://i.imgur.com/Yg8Xw3O.jpg',
  },
];

const trendingCategories = [
  {
    id: '7',
    name: 'Summer Essentials',
    image: '../../assets/images/sale5.webp',
  },
  {
    id: '8',
    name: 'Luxury Bags',
    image: 'https://i.imgur.com/oYiTqum.jpg',
  },
];

const AnimatedCategoryButton = ({ label }) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <TouchableWithoutFeedback
      onPressIn={() => (scale.value = withSpring(0.95))}
      onPressOut={() => (scale.value = withSpring(1))}
    >
      <Animated.View style={[styles.categoryButton, animatedStyle]}>
        <Text style={styles.categoryText}>{label}</Text>
      </Animated.View>
    </TouchableWithoutFeedback>
  );
};

const Section = ({ title, data }) => (
  <Animated.View entering={FadeInUp.delay(300).duration(400)}>
    <Text style={styles.sectionTitle}>{title}</Text>
    <FlatList
      data={data}
      keyExtractor={(item) => item.id}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.productList}
      renderItem={({ item }) => (
        <Animated.View
          style={styles.productCard}
          entering={FadeInUp.delay(400).duration(400)}
        >
          <Image source={{ uri: item.image }} style={styles.productImage} />
          <Text style={styles.productName}>{item.name}</Text>
          <Text style={styles.productPrice}>{item.price}</Text>
        </Animated.View>
      )}
    />
  </Animated.View>
);

const ExploreScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <Animated.View entering={FadeInUp.delay(100).duration(400)}>
        <Text style={styles.heading}>✨ Explore Products</Text>
        <TextInput
          style={styles.searchBar}
          placeholder="Search products..."
          placeholderTextColor="#888"
        />
      </Animated.View>

      <Animated.View
        style={styles.categoriesContainer}
        entering={FadeInUp.delay(200).duration(400)}
      >
        {categories.map((cat) => (
          <AnimatedCategoryButton key={cat} label={cat} />
        ))}
      </Animated.View>

      {/* Promotional Banner */}
      <Image
        source={{ uri: 'https://i.imgur.com/fHyEMsl.jpg' }}
        style={styles.promoBanner}
      />

      {/* Featured Section */}
      <Section title="🔥 Featured" data={featuredProducts} />

      {/* New Arrivals */}
      <Section title="🆕 New Arrivals" data={newArrivals} />

      {/* Trending Categories (Full-width Cards) */}
      <Animated.View entering={FadeInUp.delay(400).duration(400)}>
        <Text style={styles.sectionTitle}>✨ Trending Categories</Text>
        {trendingCategories.map((item) => (
          <View key={item.id} style={styles.trendingCard}>
            <Image source={{ uri: item.image }} style={styles.trendingImage} />
            <Text style={styles.trendingText}>{item.name}</Text>
          </View>
        ))}
      </Animated.View>
    </ScrollView>
  );
};

export default ExploreScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fefefe',
    paddingTop: 60,
    paddingHorizontal: 16,
  },
  heading: {
    fontSize: 28,
    fontWeight: '700',
    color: '#333',
    marginBottom: 16,
  },
  searchBar: {
    backgroundColor: '#f1f1f1',
    padding: 12,
    borderRadius: 12,
    fontSize: 16,
    marginBottom: 20,
    borderColor: '#ddd',
    borderWidth: 1,
  },
  categoriesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 24,
  },
  categoryButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    backgroundColor: 'transparent',
  },
  categoryText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 12,
    color: '#444',
  },
  productList: {
    paddingBottom: 20,
  },
  productCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 12,
    marginRight: 16,
    width: 160,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 4,
    alignItems: 'center',
  },
  productImage: {
    width: 120,
    height: 100,
    borderRadius: 10,
    marginBottom: 8,
  },
  productName: {
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
    color: '#222',
  },
  productPrice: {
    fontSize: 14,
    color: '#888',
  },
  promoBanner: {
    width: '100%',
    height: 140,
    borderRadius: 14,
    marginBottom: 24,
    resizeMode: 'cover',
  },
  trendingCard: {
    marginBottom: 16,
  },
  trendingImage: {
    width: screenWidth - 32,
    height: 150,
    borderRadius: 14,
  },
  trendingText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 6,
    color: '#333',
  },
});
