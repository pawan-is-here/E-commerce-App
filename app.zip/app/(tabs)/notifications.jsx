import React from 'react';
import {
  Image,
  SafeAreaView,
  SectionList,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

const DATA = [
  {
    title: 'Today',
    data: [
      {
        id: '1',
        name: 'Stephan Louis',
        action: 'Bought your product.',
        time: '10:04 AM',
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
        showFollow: false,
      },
      {
        id: '2',
        name: 'Hannah Flores',
        action: 'Rated your product: 5 stars',
        time: '10:00 AM',
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
        showFollow: true,
      },
      {
        id: '3',
        name: 'Hannah Flores',
        action: 'commented on your product.',
        time: '9:56 AM',
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
        showFollow: false,
      },
    ],
  },
  {
    title: 'Yesterday',
    data: [
      {
        id: '4',
        name: 'Ashley Bean',
        action: 'liked your Store.',
        time: '8:55 AM',
        avatar: 'https://randomuser.me/api/portraits/women/33.jpg',
        showFollow: false,
      },
      {
        id: '5',
        name: 'Hannah Flores',
        action: 'commented on your product.',
        time: '9:55 AM',
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
        showFollow: false,
      },
      {
        id: '6',
        name: 'Tim Marshall',
        action: 'liked your Store.',
        time: '8:02 PM',
        avatar: 'https://randomuser.me/api/portraits/men/45.jpg',
        showFollow: true,
      },
      {
        id: '7',
        name: 'Tim Marshall',
        action: 'Sent you a message.',
        time: '08:00 AM',
        avatar: 'https://randomuser.me/api/portraits/men/45.jpg',
        showFollow: false,
      },
    ],
  },
];

const NotificationItem = ({ item }) => (
  <View style={styles.card}>
    <Image source={{ uri: item.avatar }} style={styles.avatar} />
    <View style={styles.info}>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.action}>{item.action}</Text>
    </View>
    {item.showFollow ? (
      <TouchableOpacity style={styles.followButton}>
        <Text style={styles.followText}>Follow</Text>
      </TouchableOpacity>
    ) : null}
    <Text style={styles.time}>{item.time}</Text>
  </View>
);

const NotificationsScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#fff" barStyle="dark-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Notifications</Text>
      </View>

      <SectionList
        sections={DATA}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <NotificationItem item={item} />}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={styles.sectionHeader}>{title}</Text>
        )}
        contentContainerStyle={{ paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
};

export default NotificationsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    paddingTop: 20,
    paddingBottom: 15,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 2 },
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
  },
  sectionHeader: {
    backgroundColor: '#f7f7f7',
    paddingHorizontal: 14,
    paddingVertical: 8,
    fontWeight: '600',
    fontSize: 15,
    color: '#555',
    borderBottomColor: '#e0e0e0',
    borderBottomWidth: 1,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    backgroundColor: '#fff',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  name: {
    fontWeight: '600',
    fontSize: 14,
    color: '#000',
  },
  action: {
    fontSize: 13,
    color: '#444',
    marginTop: 2,
  },
  time: {
    fontSize: 12,
    color: '#aaa',
    marginLeft: 8,
  },
  followButton: {
    backgroundColor: '#007bff',
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
    marginLeft: 10,
  },
  followText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 13,
  },
});
